#pragma once

#include "PoseHandler.hpp"

#include <functional>

namespace adas {
    // class ICommand
    // { 
    // public:   
    //     //��������������������ʹ��麯��DoOperate������
    //     virtual ~ICommand() = default;  
    //     virtual void DoOperate(PoseHandler &poseHandler) const noexcept = 0;
    // };
    class MoveCommand final // : public ICommand//����һ��Ƕ����MoveCommand�����Move������Mָ�
    {
    public:
        // //ִ��Move��������Ҫί��ExecutorImp&ִ��������ɶ���
        // void DoOperate(PoseHandler &poseHandler) const noexcept
        // {
        //     poseHandler.Move();
        //     // ������� fast ״̬���ٶ���ִ��һ�� Move
        //     if (poseHandler.isFast()) {
        //         poseHandler.Move();
        //     }
        // }

        // ���庯������operate�����ܲ���PoseHandler������void
        void operator()(PoseHandler &poseHandler) const noexcept
        {
            if(poseHandler.isFast())
            {
                if(poseHandler.isReverse())
                    poseHandler.Backward();
                else
                    poseHandler.Forward();
            }

            if(poseHandler.isReverse())
                poseHandler.Backward();
            else
                poseHandler.Forward();
        }
    };
    class TurnLeftCommand final // : public ICommand
    {
        public:
            // void DoOperate(PoseHandler &poseHandler) const noexcept
            // {
            //     char oldHeading = poseHandler.Query().heading;
            //     if (poseHandler.isFast() && oldHeading == 'E') {
            //         poseHandler.Move();
            //     }
            //     poseHandler.TurnLeft();
            // }

        void operator()(PoseHandler &poseHandler) const noexcept
        {
            if (poseHandler.isFast())
            {
                if(poseHandler.isReverse())
                    poseHandler.Backward();
                else
                    poseHandler.Forward();
            }
            if(poseHandler.isReverse())
                poseHandler.TurnRight();
            else
                poseHandler.TurnLeft();
        };
    };
    class TurnRightCommand final // : public ICommand
    {
        public:
            // void DoOperate(PoseHandler &poseHandler) const noexcept
            // {
            //     char oldHeading = poseHandler.Query().heading;
            //     if (poseHandler.isFast() && oldHeading == 'E') {
            //         poseHandler.Move();
            //     }
            //     poseHandler.TurnRight();
            // }

        void operator()(PoseHandler &poseHandler) const noexcept
        {
            if (poseHandler.isFast())
            {
                if(poseHandler.isReverse())
                    poseHandler.Backward();
                else
                    poseHandler.Forward();
            }
            if(poseHandler.isReverse())
                poseHandler.TurnLeft();
            else
                poseHandler.TurnRight();
        }
    };
    class FastCommand final // : public ICommand
    {
        public:
        //     void DoOperate(PoseHandler &poseHandler) const noexcept override
        //     {
        //         poseHandler.Fast(); 
        //     }

        void operator()(PoseHandler& poseHandler) const noexcept 
        {
            poseHandler.Fast();
        };
    };
    class ReverseCommand final
    {
    public:
        void operator()(PoseHandler &poseHandler) const noexcept
        {
            poseHandler.Reverse();
        }
    };
}