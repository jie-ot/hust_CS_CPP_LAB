#include "ExecutorImpl.hpp"
//#include "Command.hpp"
#include "./cmder/CmderFactory.hpp"
#include "./cmder/NormalOrchestrator.hpp"
#include "./cmder/BusOrchestrator.hpp"
#include "./cmder/SportsCarOrchestrator.hpp"
#include "./core/Singleton.hpp" 

#include <algorithm>
//#include <memory>
//#include <unordered_map>
//#include <new>

namespace adas{
    ExecutorImpl::ExecutorImpl(const Pose &pose, CmderOrchestrator *orchestrator) noexcept
        : poseHandler(pose), orchestrator(orchestrator) {}


    Pose ExecutorImpl::Query(void) const noexcept{
        return poseHandler.Query();
    }

    /*
        std::nothrow��C++��׼���е�һ������������ָʾ�ڷ����ڴ�ʱ���׳��κ��쳣��
        ����std::nothrow_t���͵�ʵ����ͨ������new�������std::nothrow�����ռ��У�
        �������ڴ�������ڷ���ʧ��ʱ����һ����ָ�룬�������׳� std::bad_alloc�쳣
    */
    Executor *Executor::NewExecutor(const Pose &pose, const ExecutorType executorType) noexcept{
        CmderOrchestrator *orchestrator = nullptr;
        switch (executorType)
        {
            case ExecutorType::NORMAL:
                orchestrator = new (std::nothrow) NormalOrchestrator();
                break;
            case ExecutorType::SPORTS_CAR:{
                orchestrator = new (std::nothrow) SportsCarOrchestrator();
                break;
            }
            case ExecutorType::BUS:
                orchestrator = new (std::nothrow) BusOrchestrator();
                break;
        }
        return new (std::nothrow) ExecutorImpl(pose, orchestrator); 
    }

    void ExecutorImpl::Execute(const std::string &commands) noexcept{

        const auto cmders = Singleton<CmderFactory>::Instance().GetCmders(commands);

        std::for_each(
            cmders.begin(),
            cmders.end(),
            [this](const Cmder &cmder) noexcept {
                cmder(poseHandler, *orchestrator).DoOperate(poseHandler);
            }
        );

    }
}
        // // ������
        // std::unordered_map<char, std::function<void(PoseHandler& PoseHandler)>> cmderMap {
        //     {'M', MoveCommand()},               //ǰ��
        //     {'L', TurnLeftCommand()},           //��ת
        //     {'R', TurnRightCommand()},          //��ת
        //     {'F', FastCommand()},               //����
        //     {'B', ReverseCommand()},            //����
        // };

        // // // ��������M��ǰ��ָ���ӳ���ϵ
        // // // MoveCommand moveCommand;
        // // cmderMap.emplace('M', MoveCommand());
        // // // TurnLeftCommand turnLeftCommand;
        // // cmderMap.emplace('L', TurnLeftCommand());
        // // // TurnRightCommand turnrightCommand;
        // // cmderMap.emplace('R', TurnRightCommand());
        // // // FastCommand fastCommand;
        // // cmderMap.emplace('F', FastCommand()); 

        // //����commands�����ÿ��ָ��cmd
        // for(const auto cmd : commands)
        // {
        //     //std::unique_ptr<ICommand> cmder = nullptr;  

        //     const auto it = cmderMap.find(cmd);
        //     if(it != cmderMap.end()){
        //         it -> second(poseHandler);
        //     }
        //     // //���ָ����M
        //     // if(cmd == 'M'){
        //     //     // Move();
        //     //     // std::unique_ptr<MoveCommand> cmder=std::make_unique<MoveCommand>();
        //     //     // cmder->DoOperate(*this);
        //     //     cmder = std::make_unique<MoveCommand>();
        //     // }
        //     // //���ָ����L
        //     // else if(cmd == 'L'){
        //     //     //TurnLeft();
        //     //     //std::unique_ptr<TurnLeftCommand> cmder=std::make_unique<TurnLeftCommand>();
        //     //     //cmder->DoOperate(*this);
        //     //     cmder = std::make_unique<TurnLeftCommand>();
        //     // }
        //     // //���ָ����R
        //     // else if(cmd == 'R'){
        //     //     //TurnRight();
        //     //     //std::unique_ptr<TurnRightCommand> cmder=std::make_unique<TurnRightCommand>();
        //     //     //cmder->DoOperate(*this);
        //     //     cmder = std::make_unique<TurnRightCommand>();
        //     // }
        //     // //���ָ����F
        //     // else if (cmd == 'F') {
        //     //     cmder = std::make_unique<FastCommand>();
        //     // }
            
        //     // if(cmder){
        //     //     cmder->DoOperate(poseHandler);
        //     // }
        // }

    // // Move����
    // void ExecutorImpl::Move(void) noexcept
    // {
    //     if (pose.heading == 'E')        { ++pose.x; }
    //     else if (pose.heading == 'W')   { --pose.x; }
    //     else if (pose.heading == 'N')   { ++pose.y; }
    //     else if (pose.heading == 'S')   { --pose.y; }
    // }
    // // TurnLeft����
    // void ExecutorImpl::TurnLeft(void) noexcept
    // {
    //     if (pose.heading == 'E') { pose.heading = 'N'; }
    //     else if (pose.heading == 'W') { pose.heading = 'S'; }
    //     else if (pose.heading == 'N') { pose.heading = 'W'; }
    //     else if (pose.heading == 'S') { pose.heading = 'E'; }
    // }
    // // TurnRight����
    // void ExecutorImpl::TurnRight(void) noexcept
    // {
    //     if (pose.heading == 'E') { pose.heading = 'S'; }
    //     else if (pose.heading == 'W') { pose.heading = 'N'; }
    //     else if (pose.heading == 'N') { pose.heading = 'E'; }
    //     else if (pose.heading == 'S') { pose.heading = 'W'; }
    // }
    // // Fast����
    // void ExecutorImpl::Fast(void) noexcept
    // {
    //     isFast = !isFast;
    // }
    // // isFast����
    // bool ExecutorImpl::IsFast(void) const noexcept
    // {
    //     return isFast;
    // }
