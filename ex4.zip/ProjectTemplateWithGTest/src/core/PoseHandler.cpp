#include "PoseHandler.hpp"

namespace adas
{
    PoseHandler::PoseHandler(const Pose &pose) noexcept 
        :  point(pose.x, pose.y), facing(&Direction::GetDirection(pose.heading)) {}

    void PoseHandler::Forward(void) noexcept
    {
        // if (pose.heading == 'E')        { ++pose.x; }
        // else if (pose.heading == 'W')   { --pose.x; }
        // else if (pose.heading == 'N')   { ++pose.y; }
        // else if (pose.heading == 'S')   { --pose.y; }
        point += facing->Move();
    }

    void PoseHandler::Backward(void) noexcept
    {
        point -= facing->Move();
    }

    void PoseHandler::TurnLeft(void) noexcept
    {
        // if (pose.heading == 'E') { pose.heading = 'N'; }
        // else if (pose.heading == 'W') { pose.heading = 'S'; }
        // else if (pose.heading == 'N') { pose.heading = 'W'; }
        // else if (pose.heading == 'S') { pose.heading = 'E'; }
        facing = &(facing->LeftOne());
    }

    void PoseHandler::TurnRight(void) noexcept
    {
        // if (pose.heading == 'E') { pose.heading = 'S'; }
        // else if (pose.heading == 'W') { pose.heading = 'N'; }
        // else if (pose.heading == 'N') { pose.heading = 'E'; }
        // else if (pose.heading == 'S') { pose.heading = 'W'; }
        facing = &(facing->RightOne());
    }

    void PoseHandler::Fast(void) noexcept
    {
        m_isFast = !m_isFast;
    }

    void PoseHandler::Reverse(void) noexcept
    {
        m_isReverse = !m_isReverse;
    }

    bool PoseHandler::isFast(void) const noexcept
    {
        return m_isFast;
    }

    bool PoseHandler::isReverse(void) const noexcept
    {
        return m_isReverse;
    }

    Pose PoseHandler::Query(void) const noexcept
    {
        return {point.GetX(), point.GetY(), facing->GetHeading()};
    }
}