#include "Direction.hpp"

namespace adas{

    //4�ַ���
    static const Direction directions[4] = {
        {0, 'E'},
        {1, 'S'},
        {2, 'W'},
        {3, 'N'},
    };
    //4��ǰ������
    static const Point points[4] = {
        {1, 0},   // E
        {0, -1},  // S
        {-1, 0},  // W
        {0, 1},   // N
    };

    const Direction& Direction::GetDirection(const char heading) noexcept
    {
        for(const auto& direction : directions){
            if(direction.heading == heading){
                return direction;
            }
        }

        return directions[3];
    }

    Direction::Direction(const unsigned idex, const char heading) noexcept : idex(idex), heading(heading) {}
    
    const Point& Direction::Move(void) const noexcept
    {
        return points[idex];
    }

    const Direction& Direction::LeftOne(void) const noexcept
    {
        return directions[(idex + 3) % 4];
    }

    const Direction& Direction::RightOne(void) const noexcept
    {
        return directions[(idex + 1) % 4];
    }

    const char Direction::GetHeading(void) const noexcept
    {
        return heading;
    }
}

