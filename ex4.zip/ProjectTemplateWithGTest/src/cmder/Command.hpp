#pragma once

#include "../core/PoseHandler.hpp"
// #include "ActionGroup.hpp"
#include "CmderOrchestrator.hpp"

#include <functional>

namespace adas {
    // class ICommand
    // { 
    // public:   
    //     //��������������������ʹ��麯��DoOperate������
    //     virtual ~ICommand() = default;  
    //     virtual void DoOperate(PoseHandler &poseHandler) const noexcept = 0;
    // };
    class MoveCommand final // : public ICommand//����һ��Ƕ����MoveCommand�����Move������Mָ�
    {
    public:
        // �������ֱ�ӵ��� poseHandler ����ȡ��ǰ��̬
        // ����ʹ��һ�� ActionGroup ������������������
        // ÿ������������ͨ�� poseHandler ����ȡ��ǰ��̬
        // ��������ʵ�ָ����ӵĶ������
        ActionGroup operator()(PoseHandler& poseHandler, const CmderOrchestrator& orchestrator) const noexcept 
        {
            return orchestrator.Move(poseHandler);
            // ActionGroup actionGroup;

            // const auto action = poseHandler.isReverse()?
            //     ActionType::BACKWARD_1_STEP_ACTION :
            //     ActionType::FORWARD_1_STEP_ACTION ; 

            // // ����Ǽ���״̬�����ȼ���һ�ζ���
            // if (poseHandler.isFast()) {
            //     actionGroup.PushAction(action);
            // }

            // // �����Ƿ�Ϊ����״̬����һ����������Ҫ���뵽 actionGroup ȥִ��
            // actionGroup.PushAction(action);

            // return actionGroup;
        }
        // // //ִ��Move��������Ҫί��ExecutorImp&ִ��������ɶ���
        // // void DoOperate(PoseHandler &poseHandler) const noexcept
        // // {
        // //     poseHandler.Move();
        // //     // ������� fast ״̬���ٶ���ִ��һ�� Move
        // //     if (poseHandler.isFast()) {
        // //         poseHandler.Move();
        // //     }
        // // }

        // // ���庯������operate�����ܲ���PoseHandler������void
        // void operator()(PoseHandler &poseHandler) const noexcept
        // {
        //     if(poseHandler.isFast())
        //     {
        //         if(poseHandler.isReverse())
        //             poseHandler.Backward();
        //         else
        //             poseHandler.Forward();
        //     }

        //     if(poseHandler.isReverse())
        //         poseHandler.Backward();
        //     else
        //         poseHandler.Forward();
        // }
    };
    class TurnLeftCommand final // : public ICommand
    {
    public:
        ActionGroup operator()(PoseHandler &poseHandler, const CmderOrchestrator &orchestrator) const noexcept
        {
            return orchestrator.TurnLeft(poseHandler);

            // ActionGroup actionGroup;
            // const auto action = poseHandler.isReverse() ? ActionType::REVERSE_TURN_LEFT_ACTION : ActionType::TURN_LEFT_ACTION;
            // if (poseHandler.isFast())
            // {
            //     const auto action_ = poseHandler.isReverse() ? ActionType::BACKWARD_1_STEP_ACTION : ActionType::FORWARD_1_STEP_ACTION;
            //     actionGroup.PushAction(action_);
            // }
            // actionGroup.PushAction(action);
            // return actionGroup;
        }
            // void DoOperate(PoseHandler &poseHandler) const noexcept
            // {
            //     char oldHeading = poseHandler.Query().heading;
            //     if (poseHandler.isFast() && oldHeading == 'E') {
            //         poseHandler.Move();
            //     }
            //     poseHandler.TurnLeft();
            // }

        // void operator()(PoseHandler &poseHandler) const noexcept
        // {
        //     if (poseHandler.isFast())
        //     {
        //         if(poseHandler.isReverse())
        //             poseHandler.Backward();
        //         else
        //             poseHandler.Forward();
        //     }
        //     if(poseHandler.isReverse())
        //         poseHandler.TurnRight();
        //     else
        //         poseHandler.TurnLeft();
        // };
    };
    class TurnRightCommand final // : public ICommand
    {
    public:
        ActionGroup operator()(PoseHandler &poseHandler, const CmderOrchestrator &orchestrator) const noexcept
        {
            return orchestrator.TurnRight(poseHandler);

            // ActionGroup actionGroup;
            // const auto action = poseHandler.isReverse() ? ActionType::REVERSE_TURN_RIGHT_ACTION : ActionType::TURN_RIGHT_ACTION;
            // if (poseHandler.isFast())
            // {
            //     const auto action_ = poseHandler.isReverse() ? ActionType::BACKWARD_1_STEP_ACTION : ActionType::FORWARD_1_STEP_ACTION;
            //     actionGroup.PushAction(action_);
            // }
            // actionGroup.PushAction(action);
            // return actionGroup;
        }
            // void DoOperate(PoseHandler &poseHandler) const noexcept
            // {
            //     char oldHeading = poseHandler.Query().heading;
            //     if (poseHandler.isFast() && oldHeading == 'E') {
            //         poseHandler.Move();
            //     }
            //     poseHandler.TurnRight();
            // }

        // void operator()(PoseHandler &poseHandler) const noexcept
        // {
        //     if (poseHandler.isFast())
        //     {
        //         if(poseHandler.isReverse())
        //             poseHandler.Backward();
        //         else
        //             poseHandler.Forward();
        //     }
        //     if(poseHandler.isReverse())
        //         poseHandler.TurnLeft();
        //     else
        //         poseHandler.TurnRight();
        // }
    };
    class FastCommand final // : public ICommand
    {
    public:
        ActionGroup operator()(PoseHandler &poseHandler, const CmderOrchestrator &orchestrator) const noexcept
        {
            ActionGroup actionGroup;
            actionGroup.PushAction(ActionType::BE_FAST_ACTION);
            return actionGroup;
        }
            // void DoOperate(PoseHandler &poseHandler) const noexcept override
            // {
            //     poseHandler.Fast(); 
            // }

        // void operator()(PoseHandler& poseHandler) const noexcept 
        // {
        //     poseHandler.Fast();
        // };
    };
    class ReverseCommand final
    {
    public:
        ActionGroup operator()(PoseHandler &poseHandler, const CmderOrchestrator &orchestrator) const noexcept
        {
            ActionGroup actionGroup;
            actionGroup.PushAction(ActionType::BE_REVERSE_ACTION);
            return actionGroup;
        }
        // void operator()(PoseHandler &poseHandler) const noexcept
        // {
        //     poseHandler.Reverse();
        // }
    };
    class TurnRoundCommand final
    {
    public:
        ActionGroup operator()(PoseHandler &poseHandler, const CmderOrchestrator &orchestrator) const noexcept
        {
            return orchestrator.TurnRound(poseHandler);
            
            // if (poseHandler.isReverse())
            // {
            //     return ActionGroup(); // ����״̬�£�ʲô������
            // }
            // else
            // {
            //     if (poseHandler.isFast()) // ����״̬�£��ĸ�ԭ��Action
            //     {
            //         return ActionGroup({ActionType::FORWARD_1_STEP_ACTION,
            //                             ActionType::TURN_LEFT_ACTION,
            //                             ActionType::FORWARD_1_STEP_ACTION,
            //                             ActionType::TURN_LEFT_ACTION});
            //     }
            //     else // ��ͨ״̬�£�����ԭ��Action
            //     {
            //         return ActionGroup({ActionType::TURN_LEFT_ACTION,
            //                             ActionType::FORWARD_1_STEP_ACTION,
            //                             ActionType::TURN_LEFT_ACTION});
            //     }
            // }
        }
    };
}