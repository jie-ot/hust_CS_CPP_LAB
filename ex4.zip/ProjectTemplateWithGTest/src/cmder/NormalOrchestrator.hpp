#pragma once

#include "CmderOrchestrator.hpp"

namespace adas
{

    class NormalOrchestrator : public CmderOrchestrator
    {
    public:
        ActionGroup Move(const PoseHandler &poseHandler) const noexcept override
        {
            ActionGroup actionGroup;
            actionGroup += OnFast(poseHandler);
            actionGroup.PushAction(GetStepAction(poseHandler));
            return actionGroup;
        }

        ActionGroup TurnLeft(const PoseHandler &poseHandler) const noexcept override
        {
            ActionGroup actionGroup;
            actionGroup += OnFast(poseHandler);

            const auto turnAction = poseHandler.isReverse() ? ActionType::REVERSE_TURN_LEFT_ACTION : ActionType::TURN_LEFT_ACTION;

            actionGroup.PushAction(turnAction);
            return actionGroup;
        }

        ActionGroup TurnRight(const PoseHandler &poseHandler) const noexcept override
        {
            ActionGroup actionGroup;
            actionGroup += OnFast(poseHandler);

            const auto turnAction = poseHandler.isReverse() ? ActionType::REVERSE_TURN_RIGHT_ACTION : ActionType::TURN_RIGHT_ACTION;

            actionGroup.PushAction(turnAction);
            return actionGroup;
        }

        ActionGroup TurnRound(const PoseHandler &poseHandler) const noexcept override
        {
            if (poseHandler.isReverse())
            {
                return ActionGroup(); // �ڵ���״̬�²�ִ�е�ͷ����
            }

            ActionGroup actionGroup;
            if (poseHandler.isFast())
            {
                actionGroup.PushAction(ActionType::FORWARD_1_STEP_ACTION);
                actionGroup.PushAction(ActionType::TURN_LEFT_ACTION);
                actionGroup.PushAction(ActionType::FORWARD_1_STEP_ACTION);
                actionGroup.PushAction(ActionType::TURN_LEFT_ACTION);
            }
            else
            {
                actionGroup.PushAction(ActionType::TURN_LEFT_ACTION);
                actionGroup.PushAction(ActionType::FORWARD_1_STEP_ACTION);
                actionGroup.PushAction(ActionType::TURN_LEFT_ACTION);
            }
            return actionGroup;
        }

    protected:
        ActionType GetStepAction(const PoseHandler &poseHandler) const noexcept // ��ȡ��������
        {
            return poseHandler.isReverse() ? ActionType::BACKWARD_1_STEP_ACTION : ActionType::FORWARD_1_STEP_ACTION;
        }

        ActionGroup OnFast(const PoseHandler &poseHandler) const noexcept
        {
            if (poseHandler.isFast())
            {
                return ActionGroup({GetStepAction(poseHandler)}); // ����Ǽ���״̬������ִ��һ��action
            }
            return ActionGroup(); // ���򷵻ؿ�ActionGroup
        }
    };

} // namespace adas